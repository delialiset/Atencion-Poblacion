-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 28-04-2016 a las 02:07:21
-- Versión del servidor: 5.5.27
-- Versión de PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `poblacion`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `causal`
--

CREATE TABLE IF NOT EXISTS `causal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `observaciones` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `causal`
--

INSERT INTO `causal` (`id`, `nombre`, `observaciones`) VALUES
(1, 'Desacuerdo con el fallo', NULL),
(2, 'Dilación de la ejecución de sentencia', NULL),
(3, 'Demora en la tramitación del proceso.', NULL),
(4, 'Otras irregularidades en la tramitación del proceso.', NULL),
(5, 'Inconformidad con la denegación y concesión de beneficios.', NULL),
(6, 'Inconformidad con las medidas provisionales y cautelares.', NULL),
(7, 'Irregularidades en la tramitación y resolución de los índices de peligrosidad.', NULL),
(8, 'Comportamiento no ético.', NULL),
(9, 'Otros (Quejas)', NULL),
(10, 'Comportamiento inadecuado.', 'esta prueba'),
(11, 'Conducta delictiva.', NULL),
(12, 'Otros (Denuncias)', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conlugar`
--

CREATE TABLE IF NOT EXISTS `conlugar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solucion_id` int(11) DEFAULT NULL,
  `sintesis` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `clasificacion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lugar` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `responsable` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `medidas` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_FB1077A6BE7243C3` (`solucion_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `conlugar`
--

INSERT INTO `conlugar` (`id`, `solucion_id`, `sintesis`, `clasificacion`, `lugar`, `responsable`, `medidas`) VALUES
(1, 1, 'Fue lo que pasó', 'Denuncia', 'Moa', 'Marta Sánchez', '- mio\r\n- otra\r\n- otra mas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia`
--

CREATE TABLE IF NOT EXISTS `materia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `materia`
--

INSERT INTO `materia` (`id`, `nombre`, `observaciones`) VALUES
(1, 'Penal', NULL),
(2, 'Civil', NULL),
(3, 'Administrativo', 'esto es admin'),
(4, 'Laboral', NULL),
(5, 'Económico', NULL),
(6, 'Militar', NULL),
(7, 'Otros', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `organismo`
--

CREATE TABLE IF NOT EXISTS `organismo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `observaciones` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `organismo`
--

INSERT INTO `organismo` (`id`, `nombre`, `observaciones`) VALUES
(1, 'Secretaría de Gobierno.', NULL),
(2, 'Salas del TSP.', NULL),
(3, 'TSP', NULL),
(4, 'TPP', NULL),
(5, 'TMP', NULL),
(6, 'Fiscalía', NULL),
(7, 'MINJUS', NULL),
(8, 'Bufetes', NULL),
(9, 'MININT', NULL),
(10, 'Otros', NULL),
(12, 'Prueba', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `procedimiento`
--

CREATE TABLE IF NOT EXISTS `procedimiento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `materia_id` int(11) DEFAULT NULL,
  `causal_id` int(11) DEFAULT NULL,
  `tmp_id` int(11) DEFAULT NULL,
  `tpp_id` int(11) DEFAULT NULL,
  `numero` int(11) NOT NULL,
  `anno` int(11) NOT NULL,
  `tipo_proced` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_peticion` date NOT NULL,
  `forma_remision` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `promovente` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sede` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `nueva_solicitud` longtext COLLATE utf8_unicode_ci,
  `tipo_escrito` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_20D1B3E4B54DBBCB` (`materia_id`),
  KEY `IDX_20D1B3E4E0E2836D` (`causal_id`),
  KEY `IDX_20D1B3E4B2ECE136` (`tmp_id`),
  KEY `IDX_20D1B3E42A9CB205` (`tpp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `procedimiento`
--

INSERT INTO `procedimiento` (`id`, `materia_id`, `causal_id`, `tmp_id`, `tpp_id`, `numero`, `anno`, `tipo_proced`, `fecha_peticion`, `forma_remision`, `promovente`, `sede`, `nueva_solicitud`, `tipo_escrito`) VALUES
(1, 1, 3, NULL, 1, 12, 2016, 'Denuncia', '2016-05-17', 'Escritos Recibidos', 'Maria de los Angeles', 'TPP', NULL, 'Escritos colectivos'),
(2, 1, 5, 6, 1, 16, 2016, 'Queja', '2016-04-12', 'Escritos Recibidos', 'Roberto Perdomo', 'TSP', NULL, 'Escritos colectivos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE IF NOT EXISTS `rol` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rol` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `observaciones` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id`, `rol`, `observaciones`) VALUES
(1, 'ROLE_ADMINISTRADOR', ''),
(2, 'ROLE_PRESIDENTE', ''),
(3, 'ROLE_SECRETARIA', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solucion`
--

CREATE TABLE IF NOT EXISTS `solucion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `procedimiento_id` int(11) DEFAULT NULL,
  `organismo_id` int(11) DEFAULT NULL,
  `fecha_solucion` date NOT NULL,
  `tipo_solucion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `resolucion` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_52FD46FDF696A255` (`procedimiento_id`),
  KEY `IDX_52FD46FD3260D891` (`organismo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `solucion`
--

INSERT INTO `solucion` (`id`, `procedimiento_id`, `organismo_id`, `fecha_solucion`, `tipo_solucion`, `resolucion`) VALUES
(1, 1, NULL, '2016-05-15', 'Con Lugar', 'esta resolucion');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tmp`
--

CREATE TABLE IF NOT EXISTS `tmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `municipio` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `observaciones` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Volcado de datos para la tabla `tmp`
--

INSERT INTO `tmp` (`id`, `municipio`, `observaciones`) VALUES
(1, 'Gibara', NULL),
(2, 'Freyre', NULL),
(3, 'Banes', NULL),
(4, 'Antilla', 'poo'),
(5, 'Baguanos', NULL),
(6, 'Holguín', NULL),
(7, 'Calixto García', NULL),
(8, 'Cacocúm', NULL),
(9, 'Urbano Noris', NULL),
(10, 'Cueto', NULL),
(11, 'Mayarí', NULL),
(12, 'Frank País', NULL),
(13, 'Sagua de Tánamo', NULL),
(14, 'Moa', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tpp`
--

CREATE TABLE IF NOT EXISTS `tpp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provincia` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sala` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `territorio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observaciones` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `tpp`
--

INSERT INTO `tpp` (`id`, `provincia`, `sala`, `territorio`, `observaciones`) VALUES
(1, 'Holguín', 'Primera Penal', 'Holguín', NULL),
(2, 'Holguín', 'Segunda Penal', 'Sagua de Tánamo', NULL),
(3, 'Holguín', 'Tercera Penal', 'Banes', NULL),
(4, 'Holguín', 'Civil, Administrativo y Laboral', 'Holguín', 'procesos civiles'),
(5, 'Holguín', 'Económica', 'Holguín', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rol_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sede` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2265B05D4BAB96C` (`rol_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `rol_id`, `nombre`, `apellidos`, `email`, `password`, `salt`, `sede`) VALUES
(1, 3, 'Yamilka', 'Apellido1 Apellido2', 'gobierno2@hl.tsp.cu', 'hfwpLNTUbD5RiC81gkdg8wKrFGdIqMpwAFnCmmiw8aBBccdLCytSZj+jacWxkAqYHKbrhbyvepEjWJSLOwvXjg==', '09fe08577f1735ab4dfd3bc5e200ef8a', 'TPP Holguín'),
(2, 1, 'Liset', 'Campaña Aguilera', 'holinf@hl.tsp.cu', 'HN5o0WJO3ZpN4t1l2vzXOeMFjp6GzNp5DcaUVSIKCvbcWkU2WdAus2gIH1n3FBPhuWMBXtrIijCPb9UOY0i71Q==', '9abc11de9a53fe1b016fd943f0c50587', 'TPP Holguín'),
(3, 2, 'Frank', 'Bruzon Oropeza', 'frank@hl.tsp.cu', 'HvuVQcM4ZSRkBX8VnIldTM0W+Os2CAh3D2lZYdxz2BermDcItYIStRbOqoOM9enTE6MhAF4GC0tYC0ADIpf85w==', 'b7843fc9f0b340e4c0bdfd59bc0959bc', 'TPP Holguín');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `conlugar`
--
ALTER TABLE `conlugar`
  ADD CONSTRAINT `conlugar_ibfk_1` FOREIGN KEY (`solucion_id`) REFERENCES `solucion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `procedimiento`
--
ALTER TABLE `procedimiento`
  ADD CONSTRAINT `FK_20D1B3E42A9CB205` FOREIGN KEY (`tpp_id`) REFERENCES `tpp` (`id`),
  ADD CONSTRAINT `FK_20D1B3E4B2ECE136` FOREIGN KEY (`tmp_id`) REFERENCES `tmp` (`id`),
  ADD CONSTRAINT `FK_20D1B3E4B54DBBCB` FOREIGN KEY (`materia_id`) REFERENCES `materia` (`id`),
  ADD CONSTRAINT `FK_20D1B3E4E0E2836D` FOREIGN KEY (`causal_id`) REFERENCES `causal` (`id`);

--
-- Filtros para la tabla `solucion`
--
ALTER TABLE `solucion`
  ADD CONSTRAINT `FK_52FD46FD3260D891` FOREIGN KEY (`organismo_id`) REFERENCES `organismo` (`id`),
  ADD CONSTRAINT `solucion_ibfk_1` FOREIGN KEY (`procedimiento_id`) REFERENCES `procedimiento` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `FK_2265B05D4BAB96C` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
